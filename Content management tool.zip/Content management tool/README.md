# BharatIntern-Task2-Project-Management-Tool
Virtual Internship Tasks for Bharat Internship in Full Stack Development, Task 2 is about the Project Management Tool is done using PHP, SQL, JAVASCRIPT etc
